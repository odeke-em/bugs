package main

import (
	"fmt"
	"Äfoo"
)

func main() {
	fmt.Printf("Äfoo.Äbar(33) returns %v\n", Äfoo.Äbar(33))
}
