package main

import (
	"common"
)

func main() {
	common.Test()
}
