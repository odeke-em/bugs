#./bin/compile_scripts.sh -i ../test/pc_test/sanguohero/scripts -o game.zip -e xxtea_zip -ek MYKEY -es XT
#./bin/compile_scripts.sh -m files -i ../test/pc_test/sanguohero/scripts -o scripts -e xxtea_chunk -ek MYKEY -es XT
./bin/compile_scripts.sh -m files -i out -o scripts -e xxtea_chunk -ek MYKEY -es XT
